/*
 * Copyright 2011 Gary R. Van Sickle (grvs@users.sourceforge.net).
 *
 * This file is part of CoFlo.
 *
 * CoFlo is free software: you can redistribute it and/or modify it under the
 * terms of version 3 of the GNU General Public License as published by the Free
 * Software Foundation.
 *
 * CoFlo is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * CoFlo.  If not, see <http://www.gnu.org/licenses/>.
 */

/** @file */

#ifndef LABEL_H_
#define LABEL_H_

#include "PseudoStatement.h"
#include <string>

/*
 *
 */
class Label: public PseudoStatement
{
public:
	Label(const Location &location, const std::string &identifier);
	Label(const Label& orig);
	virtual ~Label();

	virtual std::string GetIdentifier() const { return m_identifier; };
	virtual std::string GetStatementTextDOT() const { return m_identifier; };
	virtual std::string GetIdentifierCFG() const { return m_identifier; };

private:

	/// The label's text.
	std::string m_identifier;
};

#endif /* LABEL_H_ */
